# Summer-task4
 OpenCV project
